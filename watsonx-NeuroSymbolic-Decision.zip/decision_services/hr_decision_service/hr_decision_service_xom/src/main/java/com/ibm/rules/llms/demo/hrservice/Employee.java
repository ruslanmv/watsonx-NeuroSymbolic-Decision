package com.ibm.rules.llms.demo.hrservice;

public class Employee {
    public String name;
    public String hiringDate;
}
